<?php
require_once 'core/App.php';
require_once 'core/Controller.php';
require_once 'core/Databases.php';
require_once 'config/config.php';
require_once 'core/Ecr.php';
require_once 'core/Notif.php';
require_once 'core/Redirect.php';
require_once 'core/Chapta.php';
require_once 'core/Script.php';
require_once 'core/Mail.php';
require_once 'core/Url.php';
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

