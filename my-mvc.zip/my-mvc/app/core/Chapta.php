<?php

class Chapta{



public static function set_chapta(){

    $awal = rand('3','9');
    $akhir = rand('3','9');

    $_SESSION['chapta'] = [

        'awal' => $awal,
        'akhir' => $akhir,
        'hasil' => $awal+$akhir

    ];




}


public static function view_chapta(){

    if(isset($_SESSION['chapta'])){

    return $_SESSION['chapta']['awal']." + ".$_SESSION['chapta']['akhir'];
    }
}



public static function hasil(){

    return $_SESSION['chapta']['hasil'];
}




}