<?php


class Url{


    public static function encode($data)
    {

            return strtr( base64_encode($data), '+/=', '-_,' );

        
    }


    public static function decode($data)
    {

            return base64_decode( strtr($data, '-_,', '+/=') );
        
    }
}