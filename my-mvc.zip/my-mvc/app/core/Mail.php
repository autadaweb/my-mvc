<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class Mail{


public static function text($from,$to,$subject,$message)
{

    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP(); 
        $mail->Host       = HOST_EMAIL;
        $mail->SMTPAuth   = true;
        $mail->Username   = EMAIL;
        $mail->Password   = PASS_EMAIL;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = PORT_EMAIL;
    
        //Recipients
        $mail->setFrom(EMAIL,$from);
        $mail->addAddress($to);
        $mail->addReplyTo(EMAIL);
    
      $mail->isHTML(false);
        $mail->Subject = $subject;
        $mail->Body    = $message;
    
    
        $mail->send();
        return 'success';
    } catch (Exception $e) {
        return "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
    

}



public static function html($from,$to,$subject,$message)
{

    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->isSMTP(); 
        $mail->Host       = HOST_EMAIL;
        $mail->SMTPAuth   = true;
        $mail->Username   = EMAIL;
        $mail->Password   = PASS_EMAIL;
       $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = PORT_EMAIL;
    
        //Recipients
        $mail->setFrom(EMAIL,$from);
        $mail->addAddress($to);
        $mail->addReplyTo(EMAIL);
    
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $message;
    
    
        $mail->send();
        return 'success';
    } catch (Exception $e) {
        return "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
    

}



}

