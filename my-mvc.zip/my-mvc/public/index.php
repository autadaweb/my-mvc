<?php
//MODE DEVELOPMENT UNTUK MENAMPILKAN ERROR
ini_set( 'display_errors', true );
error_reporting( E_ALL );

if(!session_id())
{
    session_start();
}


require_once '../app/init.php';
$app = new App;

